let toy = {
    name: "Lego konstruktorius",
    image: "img/lego.jpg",
    description: "This is a toy. Buy this toy.",
    price: "57€"
}
const articlePost = document.getElementById("newsFeed")
let articleString = ""
const cheap = 39

for(let i = 0; i < 6; i++){
    if(!(i % 2 ===0))
    {
        articleString += 
        `
        <div class="toy-container">
            <div  class="image-container">
                <img class="toyImage" src=${toy.image}>
            </div>
            <h3>${toy.name}<h3>
            <p class="price">${toy.price}</p> 
            <p>${toy.description}</p>
        </div>
        `
    }
    else{
        articleString += 
        `
        <div class="toy-container">
            <div class="image-container">
                <img class="toyImage" src=${toy.image}>
            </div>
            <h3>${toy.name}<h3>
            <p class="price"><span class="big">${cheap}</span></p> <s><span class="weak">${toy.price}<span></s><br>
            <p>${toy.description}</p>
        </div>
        `
    }
}

 
 articlePost.innerHTML = articleString